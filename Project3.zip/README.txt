1. Taewoo Kim, CWID: 10696249
2. Python 2.7.14 and Windows 10
3. 
check_true_false.py reads  in the text files from the three arguments.
logical_expression.py has all the functions and algorithm to state statement's truth value depending
on the knowledgebase. 

4.
modify Path in environmental variable of computer to include C:\Python27

go to command prompt

change directory to where the python files are

type this: python check_true_false.py [wumpus_rules.txt] [additional_knowledge.txt] [statement.txt]